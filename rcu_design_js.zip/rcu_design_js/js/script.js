// DOMの読み込み
$(function(){


    // グローバル変数
    var windowWidth = $(window).width();
    var windowHeight = $(window).height();

    // console.log('読み込んだよ');

    // navの高さ
    var navContainerTop = $('.nav-container').offset().top;
    // console.log('navContainerTop: ' + navContainerTop);

    // worksContainerの高さ
    var worksContainerTop = $('.works-container').offset().top;
    console.log('worksContainerTop: ' + worksContainerTop);

// newsContainerの高さ
    var newsContainerTop =$('.news-container').offset().top;

    var slideShow =('#slide-show');
    var slidePaging = ('#slide-paging');
    var currentIndex = -1;

    function changeSlide(){
    if(currentIndex >=0{
        slideShow.find('li:eq('currentIndex+')').animate({opacity:0},1000);
    }

    }
    function nextIndex(){
        var newIndex = currentIndex+1
        changeSlide
    }
    // スクロールイベント
    $(window).on('scroll',function(){
    console.log('newsContainerTop: ' + newsContainerTop);
        // 上からのスクロール値
        var dy = $(this).scrollTop();
        console.log('dy: ' + dy);


        // PCのサイズのみ
        if(windowWidth > 767){
            // もしdyがnavContainerTop以上になったら
            if(dy >= navContainerTop){
                $('header nav').addClass('nav-fixed');
            } else {
                $('header nav').removeClass('nav-fixed');
            }
        }


        if(dy >= worksContainerTop - windowHeight){
            console.log('worksContainerTopだよ');
            $('.works-container').find('section').addClass('fade-in');
        }
         if(dy >newsContainerTop - windowHeight){
             $('.news-container').find('section').addClass('fade-in-up')
         }













    });


});
